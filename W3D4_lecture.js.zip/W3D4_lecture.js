// Data Modeling

// Array vs. Object

// Objects are better with complex data
// Not very good with iterating or sorting;

// Arrays are good for sorting
// require us to iterate over the entire arr (this could be potentially expensive)

// Ford, Mustang
// Honda, Civic
// Mazda, 626
// Chevy, Tahoe
// Dodge, Charger
// Kia, Rio

let carArr = ['Ford', 'Mustang'];

let carObj = {
    company: "Honda",
    model: "Civic"
}

carObj["model"];

let user1 = [ "Brooke", "Texas", ["Apples", "Oranges", "Blueberries"]];

let user2 = {
    name: "Brooke",
    location: "Texas",
    favFoods:["Apples", "Oranges", "Blueberries"],
    favNum: 13,
    posts: 365
};
let user3 = {
    name: "Ry",
    location: "Texas",
    favFoods:["Apples", "Oranges", "Blueberries"],
    favNum: 42,
    posts: 52
};

let user4 = {
    name: "Frankelin",
    location: "Texas",
    favFoods:["Apples", "Oranges", "Blueberries"],
    favNum: 99,
    posts: 3000
};


let arr = [user2, user3, user4];
let nums = [1,2,3,4,5]


for (let i = 0; i < arr.length; i++) {
    let pointer1 = arr[i]; // user2

    for (let j = i + 1; j < arr.length; j++) {
        let pointer2 = arr[j];

        if (pointer1.posts < pointer2.posts) {
            [arr[i], arr[j]] = [arr[j], arr[i]]; 
        }
    }
}


console.log(arr);


