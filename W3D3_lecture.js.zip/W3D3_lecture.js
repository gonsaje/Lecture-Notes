// MATH OBJECT

// console.log(Math.max(5,1,2, 3, 4));
// console.log(Math.min(5,1,2, 3, 4));
// let nums = [34, 1500, 2000, 2, -6];
// let num = 5

// console.log(Math.max(...nums)); // 2000
// console.log(Math.min(...nums)); // -6

// (...) spread operator => whatever this is attached to counts for mult arguments

// console.log(Math.floor(2.9999)); // round down to nearest integer
// console.log(Math.ceil(2.000001)); // round up to nearest integer
// console.log(Math.round(2.5)); // traditional rounding


// console.log(Math.sqrt(50)); // square root
// console.log(Math.pow(50, 22)); // 5 ^ 2 => 25


// console.log(Math.abs(2 - 4)); // returns distance from 0

// console.log(Math.random()); // random number 0 to 1
// console.log(Math.PI); // pi

// console.log(Math.sign(0)); // receives number returns -1 if negative, 1 if positive, 0 if zero

// console.log(..."letters")


// Higher Order Functions & Callback Functions
// A higher order function is a function that accepts another function as a parameter
// A callback function is a function that gets passed to a higher order function

// Callbacks vs Helpers
// helper function is a function that exists to help the main function's logic
// helper function is an extension of the main function

// Callbacks are arguments

function anything(cb) {
    console.log('before');

    cb();

    console.log("after");
}

function something() {
    console.log("during");
}

// anything(something);
// anything(function hello() {console.log("hello")});



function f1(cb, str) { // respond, Crocodile
    var result = cb(str); // respond("Crocodile")
    console.log('result of callback: ' + result); // 
}

function sayGoodbye(name) {
    return 'See ya later, ' + name;
}

function respond(name) {
    return 'After a while, ' + name;
}

// f1(sayGoodbye, 'Alligator'); // See ya later, Alligator
// f1(respond, 'Crocodile');    // After a while, Crocodile

function addAndCall(num1, num2, cb) { // 7, 2, Math.sqrt
    var sum = num1 + num2; // 9
    return cb(sum); // Math.sqrt(9) => 3
}

function yellAnswer(answer) {
    console.log(answer + ' IS THE ANSWER!');
}

function double(num) {
    return num * 2;
}

// addAndCall(40, 2, yellAnswer);  // 42 IS THE ANSWER
// addAndCall(1, 1, console.log);  // 2
// console.log(addAndCall(10, 2, double));      // 24
// console.log(addAndCall(7, 2, Math.sqrt));    // 3



// Built-in Callback Methods for Arrays

/* 

<array>.forEach() 

Another way to iterate over an array

****Order Matters****:
First parameter => ele
Second parameter => index
Third parameter => array
*/

// let nums = [34, 1505, 2001, 2, -6];
// let evens = [];

// nums.forEach((num, i, arr) => {

//     // console.log(num);
//     // console.log("                 " + i);
//     // console.log("                                   " + arr);

//     if (num % 2 === 0) {
//         evens.push(num);
//     }
// })

// console.log(evens);

////////////////////////////////////////////////////////////////

/* 

<array>.map()

returns a new array with each element of the original array changed by the anon. callback function

*/

let numsArr = [34, 1505, 2001, 2, -6];

function doubled(nums) {
    return nums.map((num) => {
        return num * 2; 
    })


    // console.log(mappedArr);
    // console.log(nums);
}

console.log(doubled(numsArr));


////////////////////////////////////////////////////////////////

// <array>.filter() => returns a new array of only elements that return true when passed to the anon cb function


// let numsArr = [34, 1505, 2001, 2, -6];

// let evens = numsArr.filter((num) => {
//     return num % 2 === 0;
// }) 

// console.log(evens);



// let lettersArr = ["a", "b", "c", "d", "e"];
// let vowels = "aeiou";

// let consonants = lettersArr.filter((letter) => {
//     return vowels.indexOf(letter) === -1;
// })

// console.log(consonants);


////////////////////////////////////////////////////////////////

// <array>.every() => returns true if every element in the array returns true when passed to anon cb func
// <array>.some() => returns true if at least one element in the array returns true when passed to anon cb func

// let numsArr = [34, 1505, 2001, 2, -6];
// let result1 = numsArr.every((num) => {
//     return num > 0;
// })

// // console.log(result1);

// let result2 = numsArr.some((num) => {
//     return num < 0;
// })

// console.log(result2);