// Objects => complex data type

let arr = [1, 2, 3]; // value: element
arr[0] // reference point: index 
arr[1]

// Objects: sequence is not guranteed
// Key - Value pairs
// Keys in objects must be strings
// Values can be any kind of data type

// let obj = {
//     "color": "green",
//     "material": "wood",
//     "genome": "tree",
//     "age": 200,
//     "fruit": ["apple", "orange", "kiwi"],
//     "children": {name: "tree2"},
//     season: "winter"
// };
// Dot Notation vs. Bracket Notation

// Pulling out values: 
// <obj>.<key> You have to know the specific property Name
// console.log(obj.fruit);
// console.log(obj.season);

// <obj>["key"] // always call using a string
// console.log(obj["age"]);
// let exampleKey = "genome";

// console.log(obj[exampleKey]); // obj["genome"]

//////////////////////////////////////
// Set/Replace values

// <obj>.<key> You have to know the specific property Name
// obj.condition = "wilting"; // Set a new K,V pair
// // console.log(obj);

// obj.age += 1000; // Reassigning a value at an existing Key

// console.log(obj);

// <obj>["key"] // always call using a string
// obj["location"] = "NY";
// console.log(obj);
// obj["location"] = "SF"
// console.log(obj);
// let exampleKey = "genome";

// obj[exampleKey] = "animal"; // obj["genome"]
// console.log(obj);


// Iteration over an Object

// for...in loop


let specimen = {
    "color": "blue",
    "material": "furry",
    "genome": "lion",
    "age": 200,
    "fruit": ["apple", "orange", "kiwi"],
    "children": {name: "tree2"},
    season: "winter"
};
// console.log(arr[14]);
// console.log(specimen.dob);
      
for (let property in specimen) { // let <refPoint> in <specificObj>
    // console.log(property);
    let value = specimen[property]; // specimen["color"], specimen["material"]
    // console.log(property, value);
}


let fruits = specimen["fruit"][0];

for (let i = 0; i < specimen["fruit"].length; i++) {
    // console.log(specimen["fruit"][i]);
}

// Frequency Counter/Counter Objects

let str2 = "hello world";

function countEachChar(sentence) { // "hello world"
    let countObj = {}; // {h: 1, e: 1, l: 2, o: 1}

    for (let i = 0; i < sentence.length; i++) { // 3
        let char = sentence[i];// "l"

        if (countObj[char] === undefined) { // this key does not exist in the countObj // countObj["h"] undefined
            countObj[char] = 1; // setting the value at char // countObj["h"] = 1;
        } else {
            countObj[char] += 1; // updating the count at char
        }
    }
    return countObj;
}

// console.log(countEachChar(str2));





function freqCount(str) {
    // code here...
    let count = {};

    for (let i = 0; i < str.length; i++) {
        let char = str[i];

        if (count[char] === undefined) {
            count[char] = 1;
        } else {
            count[char] += 1;
        }
    }

    return count;
}

// var str = 'go dog go';
// console.log(freqCount(str)); // => { g: 3, o: 3, d: 1 }

var votingResults = [
    "Janice",
    "Henry", 
    "Janice",
    "Henry",
    "Janice",
    "Janice",
    "Henry",
    "Janice",
    "Henry",
    "Janice",
    "Henry",
    "Janice",
    "Janice",
    "Henry",
    "Andrew",
    "Andrew",
    "Andrew"
  ];

  /* 
  receive array of names
  init new obj
  loop over arr
  check if name(key) exists in obj 
  if does not set to 1
  if does increment 1

  return count
  */

function countVotes(results) {
    // code here...
    let count = {};

    for (let i = 0; i < results.length; i++) {
        let name = results[i];

        if (count[name] === undefined) {
            count[name] = 1;

        } else {
            count[name]++;
        }
    }

    return count;
};

console.log(countVotes(votingResults)); 
  // => { Henry: 6, Janice: 8 }

let result1 = countVotes(votingResults)
let arr1 = [1,2,3]; //find the greatest value and return the index place

/* 
receive obj

init var to track name (empty)
init new var to track maxCount = 0

loop over obj (for..in)
grab each value at each key
if value is greater than maxCount => replace maxCount and name

return string (name)
*/

// console.log(Object.values(result1));
// console.log(Object.keys(result1));

function whoTheWinner(obj) { // { Henry: 6, Janice: 8, Andrew: 3 } //find the greatest value and return key
    let name = "No One"; // "Janice"
    let maxCount = 0; // 8

    for (let key in obj) { // { Henry: 6, Janice: 8, Andrew: 3 } key => Andrew
        let count = obj[key]; // obj["Andrew"] => 3
        console.log(key);


        if (count > maxCount) { // 3 > 8
            name = key;
            maxCount = count; 
        }
    }

    return "The winner is " + name;
}

// console.log(whoTheWinner(result1)); // => "The winner is Janice"


var allUsers = {
    user1 : {
      name: "Hayden",
      friends: ["Samantha", "Miles", "Jacob"],
    },
    user2 : {
      name: "Tad",
      friends: ["Shareen", "Anthony"],
    }
}
  
  
  
function printAllTheFriendNames(allUsers) {

}

printAllTheFriendNames(allUsers); // Hint: console.log()
  // Samantha"
  // Miles"
  // Jacob"
  // Shareen"
  // Anthony"


function schoolPrez(votes) {
      
}

let schoolVotes = [{ Henry: 6, Janice: 8}, { Adam: 10, Jenny: 3}, { Tyson: 16, Lisa: 18}];
console.log(schoolPrez(schoolVotes)) // => Lisa