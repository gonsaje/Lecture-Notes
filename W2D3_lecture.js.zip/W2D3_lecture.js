// Nested Loops

// Loops

// we use loops to execute a certain set of code 'x' amount of times

// for (let i = 0; i < 6; i++) {
//     console.log(i); 
// }'


// Use cases:
// 1. Multi-Pointers (pairs, triplets, etc.)
// 2. Traversing multi dimensions

// for (let i = 0; i < 2; i++) {
//     console.log("outer:  " + i)

//     for (let j = 0; j < 4; j++) {
//         console.log("                       inner: " + j)
//     }
// }

// For every 1 iteration of the outer loop, you have a complete iteration of the inner loop

let students = ["Davide", "Gabriela", "Jeffrey", "Adesh"];

// for (let i = 0; i < students.length; i++) {
//     let student1 = students[i];// Gabriela

//     for (let j = i + 1; j < students.length; j++) {
//         let student2 = students[j]; // Gabriela

//         console.log([student1, student2]);
//     }
// }


//                 i
//                       j
// Print all unique pairs of numbers that sum up to the given target num;

// function twoSum(arr, target) {
//     for (let i = 0; i < arr.length; i++) { // 2
//         let num1 = arr[i]; // 1
        
//         for (let j = i + 1; j < arr.length; j++) {
//             let num2 = arr[j];
            
//             if (num1 + num2 === target) { // 2 + 6
//                 console.log([num1, num2]);
//             }
//         }
//     }
// }

// twoSum(numbers, 7) //=> [1, 6], [2, 5], [3, 4] 

let numbers = [0,1,2,3,4,5,6];
function threeSum(arr, target) {
    for (let i = 0; i < arr.length; i++) { // 2
        let num1 = arr[i]; // 1

        for (let j = i + 1; j < arr.length; j++) {
            let num2 = arr[j];

            for (let y = j + 1; y < arr.length; y++) {
                let num3 = arr[y];

                if (num1 + num2 + num3 === target) {
                    console.log([num1, num2, num3])
                }

            }
          
        }
    }
}

// threeSum(numbers, 7) // => [0, 1, 6], [0, 2, 5]

let obj = {
    key1: [1, 2, 3],
    key2: [2, 3, 4],
    key3: [3, 4, 5],
    key4: [4, 5, 6]
}

// for (let key in obj) {
//     let valArr = obj[key]; // arr

//     for (let i = 0; i < valArr.length; i++) {
//         let ele = valArr[i];
//         console.log(ele);
//     }
// }

// Matrix/Matrices => Multi-Dimensional Arrays

// let matrix1 = [['a','b','c'], ['d','e','f'], ['g','h','i']];
//          i: |     0       |      1       |      2      |
//          j:   0   1   2      0   1   2      0   1   2
// print every single element

let matrix1 = [
    ['a','b','c'], 
    ['d'], 
    ['g','h']
];

// console.log(matrix1[2][1])

function printEachEle(matrix) {
    for (let i = 0; i < matrix.length; i++) { // i = 0
        let set = matrix[i]; // arr => ['a','b','c']

        for (let j = 0; j < set.length; j++) {
            let letter = set[j];

            console.log(letter);
        }
    }
}

// printEachEle(matrix1);

function printReverse(matrix) {
    for (let i = matrix.length - 1; i >= 0; i--) {
        let subArr = matrix[i];

        for (let j = subArr.length - 1; j >= 0; j--) {
            let ele = subArr[j];

            console.log(ele);
        }
    }
}
printReverse(matrix1);

/* 

Given a 2D array of altitudes return the coordinates of the highest point in the
geography grid.

ex.
getHighestCoordinateOnAPlane(geography) => [2,2]
because at the location of geography[2][2] => 6
*/

function getHighestCoordinateOnAPlane(plane) {
    // code here;
}
  
  var geography = [
    [0, 2, 3, 0],
    [1, 4, 3, 1],
    [1, 5, 6, 4],
    [0, 4, 3, 2],
  ]
  
console.log(getHighestCoordinateOnAPlane(geography));
  // => [2, 2] => 6


  