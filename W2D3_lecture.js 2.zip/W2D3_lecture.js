// Loops 
// let arr = [1,2,3];

// for (let i = 0; i < arr.length; i++) {
//     console.log(arr[i]);
// }



// Nested Loops


for (let i = 0; i < 3; i++) {
    // console.log("Outside Loop   " + i );
    for (let j = 0; j < 5; j++) {
        // console.log("                           Inside Loop                   " + j);
    }
}


// Find Pairs / Mult Pointers
let students = ["Sala", "Ry", "Brooke", "Al", "Frankelin"];
//                               i 
//                                       j

for (let i = students.length - 1; i >= 0; i--) {
    let student1 = students[i];

    for (let j = i - 1; j >= 0; j--) {
        let student2 = students[j];

        for (let l = j - 1; l >= 0; l--) {
            let student3 = students[l];
            // console.log(student1, student2, student3);
        }
    }
}

// Print all pairs of numbers that sum up to the target value

function twoSum(arr, target) {
    for (let i = 0; i < arr.length; i++) {

        for (let j = i + 1; j < arr.length; j++) {

            if (arr[i] + arr[j] === target) {
                console.log([arr[i], arr[j]]);
            }
        }
    }

    return "done!"
}


// console.log(twoSum([1,2,3,4,5,6], 5)); // => [1,4], [2,3]



// Traverse Multiple Layers (2-Dimensional Arrays/Matrix)

let matrix = [
    [1, 2, 3], // 0
    [4], // 1 
    [7, 8]  // 2
//   0  1  2

];

// Print each inner element

///        | 1    2    3 | 4    5    6 | 7    8    9|
//    i:   |      0      |      1      |      2
//    j:     0    1    2   0    1    2   0    1    2


for (let i = 0; i < matrix.length; i++) {
    let sub = matrix[i];

    for (let j = 0; j < sub.length; j++) {
        let val = sub[j];
        // matrix[i][j] 
        // console.log(val);
    }

}

for (let i = matrix.length - 1; i >= 0; i--) {
    let sub = matrix[i];

    for (let j = sub.length - 1; j >= 0; j--) {
        let val = sub[j];

        console.log(val);
    }
}


let peopleArr = [
    {
        name: 'Ry', 
        favFoods:["Brownies", "Sushi", "Tacos"]
    }, 
    {
        name: "Brooke", 
        favFoods:["Apples", "Bananas", "Pears"]
    }
]



for (let i = 0; i < peopleArr.length; i++) { // looping over the outer array
    let person = peopleArr[i]; //  { name: 'Ry', favFoods:["Brownies", "Sushi", "Tacos"]}
    let foods = person.favFoods; // ["Brownies", "Sushi", "Tacos"]

    for (let j = 0; j < foods.length; j++) { //looping over the inner array
        let food = foods[j]; // Brownies 

        // console.log(person.name + " enjoys " + food);
    }

}



function getHighestCoordinateOnAPlane(plane) {
    // code here;
}
  
var geography = [
    [0, 2, 3, 0],
    [1, 4, 3, 1],
    [1, 5, 6, 4],
    [0, 4, 3, 2],
]
  
var geography1 = [
    [-10, -2, -3, -10],
    [-1, -4, -3, -10],
    [-10, -5, -6, -4],
    [-10, -4, -3, -2],
]
console.log(getHighestCoordinateOnAPlane(geography));
  // => [2, 2]

  console.log(getHighestCoordinateOnAPlane(geography1)); // => [1, 0]

  // Additional follow up question => What happens if all values are negative
  