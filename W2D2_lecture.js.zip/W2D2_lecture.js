// OBJECTS // complex data type

let arr = [1, 2, 3, 4];
let firstEle = arr[0];

// Arrays are sequenced list-like objects

// Objects: sequence is not guaranteed// dont have sequence
// Key - Value Pairs
// Values: can be any kind of data type
// Keys: must be string

let obj = {
    "name": "Jae",
    "age": 24,
    "favFoods": ["pizza", "gummy bears", "popcorn"],
    "isAwake": true
} 

let obj1 = {
    candy: "lollipop"
}

// console.log(obj["name"]);
// console.log(obj1["candy"])

// Setting properties in objects / Getting Properties

// dot notation: you know exactly what the key name is

// <object>.<keyName>

// console.log(obj.isAwake);
obj.location = "NYC";

// bracket notation: you might know what the key name is, you might not
obj["favColor"] = "Green";
// console.log(obj["name"]);
// console.log(obj1["candy"])

// console.log(obj);
let key = "age";

// console.log(obj[key]); // obj["age"]

// indexOf()

// console.log(obj["hometown"])

function buildDog(name, breed, favToys) { // "Fido", "Bulldog", ['ball', 'rope', 'shoe']
    let dog = {
    };

    // dog.name = name;
    // dog.breed = breed;
    
    dog["name"] = name;
    dog["breed"] = breed;
    dog.favToys = favToys;
    // dog.favToys = favToys;


    return dog;
}
buildDog("Fido", "Bulldog", ['ball', 'rope', 'shoe'])
console.log(buildDog("Fido", "Bulldog", ['ball', 'rope', 'shoe']));
console.log(buildDog("Dixie", "Border Collie", ["Sheep"]));

// let dog1 = buildDog("Fido", "Bulldog", ['ball', 'rope', 'shoe']);

// Print out dog1's second fav toy?

// let favToysArr = dog1.favToys; // arr
// console.log(favToysArr[1])

// Iterating over an object

// For loop => (for..in loop)

let user1 = {
    name: "Frank Coleman",
    friends: ["Hendrick Ramos", "Binh Nguyen", "Davide Lepri"],
    favoriteActivities: ["Cycling", "Swimming"],
    yearsActive: 10
}

// for (let key in user1) {
//     let value = user1[key];

//     console.log(`key of ${key} is pointing to value of ${value}`);
// }



var user2 = {
    email : "user@gmail.com",
    address : "636 lyon street",
    hobbies : ["biking", "exploring"],
    isOnline : true,
    securityQuestions : {
      grandfathersName : "Art",
      favoriteColor : "blue"
    }
};

function printSecurityQuestions(user) {
    let securityQuestions = user.securityQuestions; // secQues => obj 
    // {
    //     grandfathersName : "Art",
    //     favoriteColor : "blue"
    //   }

    for (let question in securityQuestions) { // grandFathersName in securityQuestions
        let value = securityQuestions[question]; // securityQuestions["grandFathersName"] => "Art"

        console.log(`${question} pointing to ${value}`);
    }
}

// printSecurityQuestions(user2)
//=> "grandfathersName pointing to Art" 
//=> "favoriteColor pointing to blue"   

// Frequency Counters

function countWords(sentence) { // "sunglasses"
    let count = {}; // {h: 1, e: 1, l: 2, o: 1}
    let words = sentence.split(" "); 
    for (let i = 0; i < words.length; i++) { // i = 4
        let word = words[i]; // char = "o"

        if (count[word] !== undefined) { // count["o"] === undefined
            count[word] += 1; // count["l"] += 1 => 1 += 1 => 2
        } else {
            count[word] = 1; // count["o"] = 1
        }
    }

    return count;
}

console.log(countChars("hello world, I am learning code. hello davide")); //=>
console.log(countChars("sunglasses")) // => {h: 1, e: 1, l: 2, o: 1}


function buildDog(name, breed, favToys) { // "Fido", "Bulldog", ['ball', 'rope', 'shoe']
    let dog = {};

    dog["name"] = name;
    dog["breed"] = breed;
    dog.favToys = favToys;
    // dog.favToys = favToys;


    return dog;
}


// for (let i = 0; i <= 5; i--) {
//     console.log(i);
// }

// camelCase blueWaterBottle  

// snake_case