// Math Object

// console.log(Math.max(1,2,31,4,5));
// console.log(Math.min(1,2,-31,4,5));

let numsArr = [13, 23, -42, 100, 12];

// spread operator ... => tells JS that the input passed in should not be read as a singular input

// console.log(Math.max(...numsArr));
// console.log(Math.min(...numsArr));

// console.log(Math.floor(2.9999999999)); // rounds down to the nearest integer
// console.log(Math.ceil(2.0000001)); // rounds up to the nearest integer
// console.log(Math.round(2.5)); // traditional rounding

// console.log(Math.sqrt(36)); // square root
// console.log(Math.pow(2, 2)); // Math.pow(<base>, <power>) 2^2 (exponent)

// console.log(Math.abs(-10)); // absolute value (distance from zero)
// console.log(Math.floor(Math.random() * 100)); // a random decimal from 0 to 1 (exclusive)

// console.log(Math.PI);
// console.log(Math.sign(0)); // returns -1 if input is a negative, 1 if input is a positive, 0 if input is zero


// Higher Order Functions & Callback Functions
// A higher order function is a function that receives another function as a parameter/argument
// A callback function is a function that is passed in as an argument to a HOF

function example(cb) { // higher order function 
    console.log('before');

    cb();

    console.log('after');
}

function callback1() { // callback
    console.log("during");
}

function callback2() {
    console.log("hello world");
}

// example(callback1);
// console.log(" ");
// example(callback2);
// console.log(" ");
// example(function(){console.log("I am example 3");})

function f1(cb, str) { // respond, 'Crocodile'
	var result = cb(str); // 
	console.log('result of callback: ' + result); 
}

function sayGoodbye(name) { // Alligator
    return 'See ya later, ' + name;
}

function respond(name) { // Crocodile 
    return 'After a while, ' + name;
}

// f1(sayGoodbye, 'Alligator'); // result of callback: See ya later Alligator
// f1(respond, 'Crocodile');    // After a while Crocodile

// Callbacks vs. Helper Functions
// Callbacks => they are part of the HOF's main functionality
//           => Callbacks can change based on the inputted function

// Helper => optional function that aids another function
//        => Will always be the same function regarless of input


function addAndCall(num1, num2, cb) { // 1, 1, console.log
    var sum = num1 + num2; // 2
    return cb(sum); // console.log(2)
}

function yellAnswer(answer) {
    console.log(answer + ' IS THE ANSWER!');
}

  function double(num) {
    return num * 2;
}

// addAndCall(40, 2, yellAnswer);  // yellAnswer(42) => 42 IS THE ANSWER
// addAndCall(1, 1, console.log);  // 2
// console.log(

//     addAndCall(10, 2, double)      // 24
// );
// console.log(

//     addAndCall(7, 2, Math.sqrt)    // 3
// );

/////////////////////////////////////////////////////////////////////
// Callbacks Methods (Built-In Methods for the Array class/prototype)


/* 
<array>.forEach()
Another way to iterate over an array

********ORDER MATTERS**************
First parameter => element
Second parameter => index
Third parameter => entire array

*/


// let nums = [1,2,3,4,5];
let evens = [];

// nums.forEach(function(ele, i, arr) {
//     console.log("element is: "+ ele);
//     console.log("               at the index of: " + i);
//     console.log("                                           in the array of: " + arr);
// })

nums.forEach((ele) => {
    if (ele % 2 === 0) {
        evens.push(ele);
    }
});

// console.log(evens);

/////////////////////////////////////////////////////////////////

/* 

<array>.map()

Returns a new array with each element of the original array 
modified by the anonymous callback function

*/

let nums = [1,2,3,4,5];


function doubled(numArr) {
    let doublesArr = numArr.map((ele, i, arr) => {
        // console.log(i, arr);
        return ele * 2;
    });

    return doublesArr;
}

// console.log(doubled(nums));

/////////////////////////////////////////////////////////////////

/* 

<array>.filter()

Returns a new array with of only elements that return true when passed
to the anon cb function

*/

let nums2 = [21, 2, -3, 45, 500];

function onlyEvens(arr) {
    let evensArr = arr.filter((ele) => { // [2, 500]
        return ele % 2 === 0;
    });

    return evensArr;
}

// console.log(onlyEvens(nums2));


function noVowels(arr) { // ["a", "b", "c", "d", "e"]
    // let consonants = arr.filter((char) => { // "e" [ "b", "c", "d"]
    //     return !"aeiou".includes(char); // if it isn't a vowel return true
    // })

    let consonants = arr.filter(function(char) { // "e" [ "b", "c", "d"]
        return !"aeiou".includes(char); // if it isn't a vowel return true
    })


    return consonants;
}

// console.log(noVowels(["a", "b", "c", "d", "e"]));

/////////////////////////////////////////////////////////////////

// <array>.every() Returns true if every element in the array returns true when passed to the anon cb

let nums3 = [52,6,7,8,92];

let result = nums3.every((num) => {
    return num % 2 === 0;
})

// console.log(result);

/////////////////////////////////////////////////////////////////

// <array>.some() Returns true if eveb one element in the array returns true when passed to the anon cb

let nums4 = [5,61,7,8,9];

let result1 = nums4.some((num) => {
    return num % 2 === 0;
})

console.log(result1);